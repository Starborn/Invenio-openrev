# -*- coding: utf-8 -*-
#
# Copyright (C) 2026 Epistemic Systems Lab, Ronin Institute.
#
# Invenio-Review is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

"""Open peer review module for InvenioRDM repositories."""

from setuptools import setup

setup()
