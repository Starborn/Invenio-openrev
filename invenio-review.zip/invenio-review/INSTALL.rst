Installation
============

Invenio-Review is on PyPI so all you need is:

.. code-block:: console

   $ pip install invenio-review
