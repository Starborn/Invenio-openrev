..
    Copyright (C) 2026 Epistemic Systems Lab, Ronin Institute.

    Invenio-Review is free software; you can redistribute it and/or modify
    it under the terms of the MIT License; see LICENSE file for more details.

================
 Invenio-Review
================

.. image:: https://github.com/Starborn/invenio-review/workflows/CI/badge.svg
        :target: https://github.com/Starborn/invenio-review/actions?query=workflow%3ACI

.. image:: https://img.shields.io/github/tag/Starborn/invenio-review.svg
        :target: https://github.com/Starborn/invenio-review/releases

.. image:: https://img.shields.io/pypi/dm/invenio-review.svg
        :target: https://pypi.python.org/pypi/invenio-review

.. image:: https://img.shields.io/github/license/Starborn/invenio-review.svg
        :target: https://github.com/Starborn/invenio-review/blob/master/LICENSE

Open peer review module for InvenioRDM repositories

TODO: Please provide feature overview of module

Further documentation is available on
https://invenio-review.readthedocs.io/
