# -*- coding: utf-8 -*-
#
# Copyright (C) 2026 Epistemic Systems Lab, Ronin Institute.
#
# Invenio-Review is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

"""Module tests."""

from flask import Flask

from invenio_review import InvenioReview


def test_version():
    """Test version import."""
    from invenio_review import __version__

    assert __version__


def test_init():
    """Test extension initialization."""
    app = Flask("testapp")
    ext = InvenioReview(app)
    assert "invenio-review" in app.extensions

    app = Flask("testapp")
    ext = InvenioReview()
    assert "invenio-review" not in app.extensions
    ext.init_app(app)
    assert "invenio-review" in app.extensions


def test_view(base_client):
    """Test view."""
    res = base_client.get("/")
    assert res.status_code == 200
    assert "Welcome to Invenio-Review" in str(res.data)
