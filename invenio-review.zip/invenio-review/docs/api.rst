..
    Copyright (C) 2026 Epistemic Systems Lab, Ronin Institute.

    Invenio-Review is free software; you can redistribute it and/or modify
    it under the terms of the MIT License; see LICENSE file for more details.


API Docs
========

.. automodule:: invenio_review.ext
   :members:

Views
-----

.. automodule:: invenio_review.views
   :members:
