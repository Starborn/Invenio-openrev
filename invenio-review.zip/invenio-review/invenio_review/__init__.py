# -*- coding: utf-8 -*-
#
# Copyright (C) 2026 Epistemic Systems Lab, Ronin Institute.
#
# Invenio-Review is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

"""Open peer review module for InvenioRDM repositories.

Invenio-Review adds a Publish-Review-Curate (PRC) workflow to any
InvenioRDM instance. It provides:

- Open (non-anonymous) peer review with structured scoring
- Editorial assessment (PRC curation stage, no binary accept/reject)
- OAMAP-compatible audit trail for all workflow actions
- Configurable review criteria, roles, and visibility settings

The module implements five data entities:

- **ReviewRequest**: links a deposited record to a review process
- **ReviewAssignment**: tracks reviewer invitations and COI declarations
- **Review**: the review itself (text, scores, recommendation)
- **EditorialAssessment**: the editor's summary (PRC curation)
- **AuditEvent**: timestamped, structured audit trail (OAMAP Layers 1-5)

Usage::

    from invenio_review.services import ReviewService

    # Author requests review
    req = ReviewService.create_request(
        record_pid="zenodo.12345",
        submitter_id=1,
        record_url="https://zenodo.org/records/12345",
    )

    # Editor assigns reviewer
    ReviewService.assign_reviewer(req.id, reviewer_id=2, assigned_by=3)

    # Reviewer submits review
    ReviewService.submit_review(
        req.id, reviewer_id=2,
        body="This paper presents a novel approach...",
        scores={"soundness": 4, "clarity": 5},
        recommendation="recommend",
    )

    # Editor publishes assessment
    ReviewService.submit_assessment(
        req.id, editor_id=3,
        summary="Two reviewers found the work sound...",
        significance="important",
    )
"""

__version__ = "0.1.0"
