# -*- coding: utf-8 -*-
#
# Copyright (C) 2026 Epistemic Systems Lab, Ronin Institute.
#
# Invenio-Review is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

"""Open peer review module for InvenioRDM repositories."""

from . import config


class InvenioReview(object):
    """Invenio-Review extension."""

    def __init__(self, app=None):
        """Extension initialization."""
        if app:
            self.init_app(app)

    def init_app(self, app):
        """Flask application initialization."""
        self.init_config(app)
        app.extensions["invenio-review"] = self

    def init_config(self, app):
        """Initialize configuration."""
        if "BASE_TEMPLATE" in app.config:
            app.config.setdefault(
                "REVIEW_BASE_TEMPLATE",
                app.config["BASE_TEMPLATE"],
            )
        for k in dir(config):
            if k.startswith("REVIEW_"):
                app.config.setdefault(k, getattr(config, k))
