# -*- coding: utf-8 -*-
#
# Copyright (C) 2026 Epistemic Systems Lab, Ronin Institute.
#
# Invenio-Review is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

"""REST API views for Invenio-Review.

Provides endpoints for the open peer review workflow:

    POST   /api/reviews/               Create review request
    GET    /api/reviews/<id>            Get review request details
    POST   /api/reviews/<id>/assign     Assign reviewer
    POST   /api/reviews/<id>/review     Submit review
    POST   /api/reviews/<id>/assess     Submit editorial assessment
    GET    /api/reviews/<id>/audit      Get audit trail
"""

from flask import Blueprint, jsonify, request as req
from invenio_db import db

from .models import ReviewRequest, AuditEvent
from .services import ReviewService

blueprint = Blueprint(
    "invenio_review",
    __name__,
    url_prefix="/api/reviews",
)


@blueprint.route("/", methods=["POST"])
def create_review_request():
    """Create a new review request."""
    data = req.get_json()
    review_req = ReviewService.create_request(
        record_pid=data["record_pid"],
        submitter_id=data["submitter_id"],
        record_url=data.get("record_url"),
        metadata=data.get("metadata", {}),
    )
    return jsonify({
        "id": str(review_req.id),
        "status": review_req.status,
        "record_pid": review_req.record_pid,
    }), 201


@blueprint.route("/<uuid:request_id>", methods=["GET"])
def get_review_request(request_id):
    """Get review request with reviews and assessment."""
    review_req = ReviewRequest.query.get_or_404(request_id)
    reviews = [{
        "id": str(r.id),
        "reviewer_id": r.reviewer_id,
        "body": r.body,
        "scores": r.scores,
        "recommendation": r.recommendation,
        "is_public": r.is_public,
        "created": r.created.isoformat() if r.created else None,
    } for r in review_req.reviews if r.is_public]

    assessment = None
    if review_req.assessment and review_req.assessment.is_public:
        a = review_req.assessment
        assessment = {
            "editor_id": a.editor_id,
            "summary": a.summary,
            "significance": a.significance,
            "strength_of_evidence": a.strength_of_evidence,
            "created": a.created.isoformat() if a.created else None,
        }

    return jsonify({
        "id": str(review_req.id),
        "record_pid": review_req.record_pid,
        "record_url": review_req.record_url,
        "status": review_req.status,
        "metadata": review_req.metadata_json,
        "reviews": reviews,
        "assessment": assessment,
    })


@blueprint.route("/<uuid:request_id>/assign", methods=["POST"])
def assign_reviewer(request_id):
    """Assign a reviewer to a review request."""
    data = req.get_json()
    assignment = ReviewService.assign_reviewer(
        request_id=request_id,
        reviewer_id=data["reviewer_id"],
        assigned_by=data["assigned_by"],
        due_date=data.get("due_date"),
    )
    return jsonify({
        "id": str(assignment.id),
        "status": assignment.status,
    }), 201


@blueprint.route("/<uuid:request_id>/review", methods=["POST"])
def submit_review(request_id):
    """Submit a review."""
    data = req.get_json()
    review = ReviewService.submit_review(
        request_id=request_id,
        reviewer_id=data["reviewer_id"],
        body=data["body"],
        scores=data.get("scores"),
        recommendation=data.get("recommendation"),
    )
    return jsonify({
        "id": str(review.id),
        "recommendation": review.recommendation,
    }), 201


@blueprint.route("/<uuid:request_id>/assess", methods=["POST"])
def submit_assessment(request_id):
    """Submit editorial assessment."""
    data = req.get_json()
    assessment = ReviewService.submit_assessment(
        request_id=request_id,
        editor_id=data["editor_id"],
        summary=data["summary"],
        significance=data.get("significance"),
        strength_of_evidence=data.get("strength_of_evidence"),
    )
    return jsonify({
        "id": str(assessment.id),
        "significance": assessment.significance,
    }), 201


@blueprint.route("/<uuid:request_id>/audit", methods=["GET"])
def get_audit_trail(request_id):
    """Get OAMAP audit trail for a review request."""
    events = AuditEvent.query.filter_by(
        request_id=request_id
    ).order_by(AuditEvent.created).all()
    return jsonify({
        "request_id": str(request_id),
        "events": [{
            "id": str(e.id),
            "action": e.action,
            "actor_id": e.actor_id,
            "oamap_layer": e.oamap_layer,
            "details": e.details,
            "created": e.created.isoformat() if e.created else None,
        } for e in events],
    })
