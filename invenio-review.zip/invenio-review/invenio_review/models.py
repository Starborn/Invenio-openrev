# -*- coding: utf-8 -*-
#
# Copyright (C) 2026 Epistemic Systems Lab, Ronin Institute.
#
# Invenio-Review is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

"""Data models for Invenio-Review.

Implements the core entities of the open peer review workflow:

- ReviewRequest: links a record (preprint) to a review process
- ReviewAssignment: links a reviewer to a review request
- Review: the actual review content (text, scores, recommendation)
- EditorialAssessment: the editor's summary assessment (PRC curation stage)
- AuditEvent: OAMAP-compatible audit trail entry
"""

import uuid
from datetime import datetime, timezone

from invenio_db import db
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy_utils import Timestamp


class ReviewRequest(db.Model, Timestamp):
    """A request to review a record (preprint/paper).

    This is the top-level entity that connects a deposited record to the
    review workflow. Created when an author requests review or an editor
    initiates review of a record.
    """

    __tablename__ = "review_requests"

    id = db.Column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    """Primary key."""

    record_pid = db.Column(db.String(255), nullable=False, index=True)
    """PID of the record under review (links to InvenioRDM record)."""

    record_url = db.Column(db.Text, nullable=True)
    """URL of the preprint (e.g. arXiv, Zenodo, or local repository URL)."""

    status = db.Column(
        db.String(50), nullable=False, default="submitted", index=True
    )
    """Current workflow status. See config.REVIEW_STATUSES."""

    submitter_id = db.Column(db.Integer, db.ForeignKey("accounts_user.id"))
    """User who submitted the review request (typically the author)."""

    editor_id = db.Column(
        db.Integer, db.ForeignKey("accounts_user.id"), nullable=True
    )
    """Editor assigned to manage this review."""

    metadata_json = db.Column(
        JSONB, default=dict, nullable=False
    )
    """Additional metadata: title, abstract, keywords, venue, etc."""

    # Relationships
    assignments = db.relationship(
        "ReviewAssignment", back_populates="request", lazy="dynamic"
    )
    reviews = db.relationship(
        "Review", back_populates="request", lazy="dynamic"
    )
    assessment = db.relationship(
        "EditorialAssessment", back_populates="request", uselist=False
    )
    audit_events = db.relationship(
        "AuditEvent", back_populates="request", lazy="dynamic",
        order_by="AuditEvent.created"
    )


class ReviewAssignment(db.Model, Timestamp):
    """Assignment of a reviewer to a review request.

    Tracks invitation, acceptance, and completion status.
    Maps to OAMAP Layer 2 (Assignment and COI).
    """

    __tablename__ = "review_assignments"

    id = db.Column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )

    request_id = db.Column(
        UUID(as_uuid=True),
        db.ForeignKey("review_requests.id"),
        nullable=False,
    )
    """The review request this assignment belongs to."""

    reviewer_id = db.Column(
        db.Integer, db.ForeignKey("accounts_user.id"), nullable=False
    )
    """The assigned reviewer."""

    assigned_by = db.Column(
        db.Integer, db.ForeignKey("accounts_user.id"), nullable=True
    )
    """Who made the assignment (editor, or self if self-assigned)."""

    status = db.Column(
        db.String(50), nullable=False, default="invited"
    )
    """Assignment status: invited, accepted, declined, completed, withdrawn."""

    coi_declared = db.Column(db.Boolean, default=False)
    """Whether the reviewer has declared no conflict of interest."""

    coi_statement = db.Column(db.Text, nullable=True)
    """Free-text COI declaration."""

    due_date = db.Column(db.DateTime, nullable=True)
    """Review due date."""

    # Relationships
    request = db.relationship("ReviewRequest", back_populates="assignments")


class Review(db.Model, Timestamp):
    """A peer review of a record.

    Contains the review text, structured scores, and recommendation.
    Maps to OAMAP Layer 3 (Review Process).
    In open review mode, reviewer identity is published with the review.
    """

    __tablename__ = "reviews"

    id = db.Column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )

    request_id = db.Column(
        UUID(as_uuid=True),
        db.ForeignKey("review_requests.id"),
        nullable=False,
    )
    """The review request this review responds to."""

    reviewer_id = db.Column(
        db.Integer, db.ForeignKey("accounts_user.id"), nullable=False
    )
    """The reviewer who wrote this review."""

    body = db.Column(db.Text, nullable=False)
    """The review text."""

    scores = db.Column(JSONB, default=dict)
    """Structured scores as JSON, keyed by criteria id.
    Example: {"soundness": 4, "clarity": 3, "originality": 5, ...}
    """

    recommendation = db.Column(db.String(50), nullable=True)
    """Reviewer recommendation: strong_recommend, recommend,
    weak_recommend, revise, do_not_recommend."""

    is_public = db.Column(db.Boolean, default=True)
    """Whether this review is publicly visible. Default True (open review)."""

    version = db.Column(db.Integer, default=1)
    """Review version (supports revised reviews)."""

    # Relationships
    request = db.relationship("ReviewRequest", back_populates="reviews")


class EditorialAssessment(db.Model, Timestamp):
    """Editor's summary assessment of a reviewed record.

    This is the curation stage of the PRC model. The editor summarises
    the strengths and weaknesses of the work based on the reviews.
    In the PRC model, this is NOT a binary accept/reject decision.
    Maps to OAMAP Layer 4 (Decision).
    """

    __tablename__ = "editorial_assessments"

    id = db.Column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )

    request_id = db.Column(
        UUID(as_uuid=True),
        db.ForeignKey("review_requests.id"),
        nullable=False,
        unique=True,
    )
    """One assessment per review request."""

    editor_id = db.Column(
        db.Integer, db.ForeignKey("accounts_user.id"), nullable=False
    )
    """The editor who wrote the assessment."""

    summary = db.Column(db.Text, nullable=False)
    """Summary of strengths and weaknesses."""

    significance = db.Column(db.String(50), nullable=True)
    """Overall significance assessment: landmark, important,
    useful, incremental, insufficient."""

    strength_of_evidence = db.Column(db.String(50), nullable=True)
    """Evidence strength: exceptional, compelling, solid, incomplete,
    inadequate."""

    is_public = db.Column(db.Boolean, default=True)
    """Whether this assessment is publicly visible."""

    # Relationships
    request = db.relationship(
        "ReviewRequest", back_populates="assessment"
    )


class AuditEvent(db.Model, Timestamp):
    """OAMAP-compatible audit trail event.

    Every action in the review workflow generates an audit event.
    This provides the structured, timestamped, verifiable record
    that the OAMAP framework requires for process accountability.

    Maps to all five OAMAP layers:
    - Layer 1: Submission Integrity (record deposit)
    - Layer 2: Assignment and COI (reviewer assignment)
    - Layer 3: Review Process (review submission)
    - Layer 4: Decision (editorial assessment)
    - Layer 5: Appeal and Recourse (status changes, withdrawals)
    """

    __tablename__ = "review_audit_events"

    id = db.Column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )

    request_id = db.Column(
        UUID(as_uuid=True),
        db.ForeignKey("review_requests.id"),
        nullable=False,
        index=True,
    )
    """The review request this event belongs to."""

    actor_id = db.Column(
        db.Integer, db.ForeignKey("accounts_user.id"), nullable=False
    )
    """The user who performed the action."""

    action = db.Column(db.String(100), nullable=False, index=True)
    """Action performed: request_created, reviewer_assigned,
    reviewer_accepted, review_submitted, status_changed,
    assessment_published, etc."""

    oamap_layer = db.Column(db.Integer, nullable=True)
    """OAMAP audit layer (1-5) this event maps to."""

    details = db.Column(JSONB, default=dict)
    """Structured details of the action as JSON.
    Example: {"from_status": "submitted", "to_status": "under_review"}
    """

    # Relationships
    request = db.relationship(
        "ReviewRequest", back_populates="audit_events"
    )
