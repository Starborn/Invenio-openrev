# -*- coding: utf-8 -*-
#
# Copyright (C) 2026 Epistemic Systems Lab, Ronin Institute.
#
# Invenio-Review is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

"""Configuration for Invenio-Review.

This module provides the default configuration values for the open peer
review workflow. All values can be overridden in the InvenioRDM instance
configuration.
"""

REVIEW_BASE_TEMPLATE = None
"""Base template for review pages. Set by init_config if theme installed."""

REVIEW_OPEN_IDENTITY = True
"""Whether reviewer identities are public (open review) or anonymous.
Default is True (open, non-anonymous review). Set to False for single-blind."""

REVIEW_ALLOW_SELF_ASSIGNMENT = False
"""Whether reviewers can self-assign to submissions."""

REVIEW_REQUIRE_EDITOR_APPROVAL = True
"""Whether reviewer assignments require editor approval."""

REVIEW_STATUSES = [
    "submitted",        # Author submitted, awaiting editor action
    "under_review",     # Editor assigned reviewers, review in progress
    "revision_requested",  # Reviews complete, author asked to revise
    "revised",          # Author submitted revision
    "editorial_assessment",  # Editor writing assessment
    "recommended",      # Editor recommends (PRC model: no accept/reject)
    "withdrawn",        # Author withdrew
]
"""Ordered list of review workflow statuses."""

REVIEW_SCORING_CRITERIA = [
    {"id": "soundness", "label": "Scientific Soundness", "max_score": 5},
    {"id": "clarity", "label": "Clarity of Presentation", "max_score": 5},
    {"id": "originality", "label": "Originality", "max_score": 5},
    {"id": "significance", "label": "Significance", "max_score": 5},
    {"id": "reproducibility", "label": "Reproducibility", "max_score": 5},
]
"""Structured scoring criteria for reviews. Configurable per instance."""

REVIEW_MAX_REVIEWERS = 5
"""Maximum number of reviewers per submission."""

REVIEW_MIN_REVIEWERS = 1
"""Minimum number of completed reviews before editorial assessment."""

REVIEW_EDITORIAL_ROLES = ["editor", "associate_editor"]
"""Roles that can manage the review workflow."""

REVIEW_AUDIT_ENABLED = True
"""Whether to generate OAMAP-compatible audit trail for all review actions.
When enabled, every status change, assignment, and review submission is
timestamped and logged as structured metadata on the record."""
