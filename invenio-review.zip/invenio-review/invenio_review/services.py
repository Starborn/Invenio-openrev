# -*- coding: utf-8 -*-
#
# Copyright (C) 2026 Epistemic Systems Lab, Ronin Institute.
#
# Invenio-Review is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

"""Service layer for Invenio-Review.

Implements the business logic for the open peer review workflow.
All state transitions generate OAMAP audit events when audit is enabled.
"""

from flask import current_app
from invenio_db import db

from .models import (
    AuditEvent,
    EditorialAssessment,
    Review,
    ReviewAssignment,
    ReviewRequest,
)


class ReviewService:
    """Service for managing the review workflow."""

    # --- Review Request lifecycle ---

    @staticmethod
    def create_request(record_pid, submitter_id, record_url=None,
                       metadata=None):
        """Create a new review request for a record.

        OAMAP Layer 1: Submission Integrity.
        """
        request = ReviewRequest(
            record_pid=record_pid,
            submitter_id=submitter_id,
            record_url=record_url,
            metadata_json=metadata or {},
            status="submitted",
        )
        db.session.add(request)
        ReviewService._audit(
            request, submitter_id, "request_created", oamap_layer=1,
            details={"record_pid": record_pid},
        )
        db.session.commit()
        return request

    @staticmethod
    def assign_editor(request_id, editor_id, assigned_by):
        """Assign an editor to a review request."""
        request = ReviewRequest.query.get_or_404(request_id)
        request.editor_id = editor_id
        ReviewService._audit(
            request, assigned_by, "editor_assigned", oamap_layer=2,
            details={"editor_id": editor_id},
        )
        db.session.commit()
        return request

    # --- Reviewer Assignment ---

    @staticmethod
    def assign_reviewer(request_id, reviewer_id, assigned_by,
                        due_date=None):
        """Assign a reviewer to a review request.

        OAMAP Layer 2: Assignment and COI.
        """
        request = ReviewRequest.query.get_or_404(request_id)
        max_reviewers = current_app.config.get("REVIEW_MAX_REVIEWERS", 5)
        current_count = request.assignments.filter(
            ReviewAssignment.status.in_(["invited", "accepted", "completed"])
        ).count()
        if current_count >= max_reviewers:
            raise ValueError(
                f"Maximum {max_reviewers} reviewers already assigned."
            )

        assignment = ReviewAssignment(
            request_id=request_id,
            reviewer_id=reviewer_id,
            assigned_by=assigned_by,
            due_date=due_date,
            status="invited",
        )
        db.session.add(assignment)
        ReviewService._audit(
            request, assigned_by, "reviewer_assigned", oamap_layer=2,
            details={
                "reviewer_id": reviewer_id,
                "due_date": str(due_date) if due_date else None,
            },
        )
        db.session.commit()
        return assignment

    @staticmethod
    def respond_to_assignment(assignment_id, reviewer_id, accept,
                              coi_declared=True, coi_statement=None):
        """Reviewer accepts or declines an assignment.

        OAMAP Layer 2: COI declaration required on acceptance.
        """
        assignment = ReviewAssignment.query.get_or_404(assignment_id)
        if assignment.reviewer_id != reviewer_id:
            raise PermissionError("Not your assignment.")

        assignment.status = "accepted" if accept else "declined"
        assignment.coi_declared = coi_declared
        assignment.coi_statement = coi_statement

        action = "reviewer_accepted" if accept else "reviewer_declined"
        ReviewService._audit(
            assignment.request, reviewer_id, action, oamap_layer=2,
            details={
                "assignment_id": str(assignment_id),
                "coi_declared": coi_declared,
            },
        )

        # If at least one reviewer accepted, move to under_review
        request = assignment.request
        if accept and request.status == "submitted":
            ReviewService._change_status(
                request, "under_review", reviewer_id
            )

        db.session.commit()
        return assignment

    # --- Review Submission ---

    @staticmethod
    def submit_review(request_id, reviewer_id, body, scores=None,
                      recommendation=None):
        """Submit a review for a record.

        OAMAP Layer 3: Review Process.
        """
        request = ReviewRequest.query.get_or_404(request_id)
        assignment = ReviewAssignment.query.filter_by(
            request_id=request_id,
            reviewer_id=reviewer_id,
            status="accepted",
        ).first()
        if not assignment:
            raise PermissionError(
                "No accepted assignment found for this reviewer."
            )

        is_public = current_app.config.get("REVIEW_OPEN_IDENTITY", True)

        review = Review(
            request_id=request_id,
            reviewer_id=reviewer_id,
            body=body,
            scores=scores or {},
            recommendation=recommendation,
            is_public=is_public,
        )
        db.session.add(review)

        assignment.status = "completed"

        ReviewService._audit(
            request, reviewer_id, "review_submitted", oamap_layer=3,
            details={
                "review_id": str(review.id) if review.id else "pending",
                "has_scores": bool(scores),
                "recommendation": recommendation,
                "is_public": is_public,
            },
        )
        db.session.commit()
        return review

    # --- Editorial Assessment ---

    @staticmethod
    def submit_assessment(request_id, editor_id, summary,
                          significance=None, strength_of_evidence=None):
        """Submit editorial assessment (PRC curation stage).

        OAMAP Layer 4: Decision.
        Note: In PRC mode, this is NOT a binary accept/reject.
        """
        request = ReviewRequest.query.get_or_404(request_id)
        if request.editor_id != editor_id:
            raise PermissionError("Only the assigned editor can assess.")

        min_reviews = current_app.config.get("REVIEW_MIN_REVIEWERS", 1)
        completed = request.reviews.count()
        if completed < min_reviews:
            raise ValueError(
                f"Need at least {min_reviews} completed reviews "
                f"(have {completed})."
            )

        assessment = EditorialAssessment(
            request_id=request_id,
            editor_id=editor_id,
            summary=summary,
            significance=significance,
            strength_of_evidence=strength_of_evidence,
            is_public=True,
        )
        db.session.add(assessment)

        ReviewService._change_status(
            request, "recommended", editor_id
        )

        ReviewService._audit(
            request, editor_id, "assessment_published", oamap_layer=4,
            details={
                "significance": significance,
                "strength_of_evidence": strength_of_evidence,
            },
        )
        db.session.commit()
        return assessment

    # --- Status Management ---

    @staticmethod
    def _change_status(request, new_status, actor_id):
        """Change review request status with audit trail."""
        old_status = request.status
        valid = current_app.config.get("REVIEW_STATUSES", [])
        if valid and new_status not in valid:
            raise ValueError(f"Invalid status: {new_status}")
        request.status = new_status
        ReviewService._audit(
            request, actor_id, "status_changed", oamap_layer=5,
            details={"from_status": old_status, "to_status": new_status},
        )

    # --- Audit Trail ---

    @staticmethod
    def _audit(request, actor_id, action, oamap_layer=None, details=None):
        """Create an OAMAP audit event if auditing is enabled."""
        if not current_app.config.get("REVIEW_AUDIT_ENABLED", True):
            return
        event = AuditEvent(
            request_id=request.id,
            actor_id=actor_id,
            action=action,
            oamap_layer=oamap_layer,
            details=details or {},
        )
        db.session.add(event)
        return event
